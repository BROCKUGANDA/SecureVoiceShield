module.exports=[44115,(e,o,d)=>{}];

//# sourceMappingURL=91859__next-internal_server_app_manifest_webmanifest_route_actions_32467c93.js.map