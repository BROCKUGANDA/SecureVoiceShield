module.exports=[67706,(e,o,d)=>{}];

//# sourceMappingURL=91859__next-internal_server_app_api_audit_segment_route_actions_2afeffa1.js.map