module.exports=[62965,(e,o,d)=>{}];

//# sourceMappingURL=3d860_SecureVoiceShield__next-internal_server_app_api_appeals_route_actions_2814a218.js.map