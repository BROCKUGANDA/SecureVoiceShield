module.exports=[19405,(e,o,d)=>{}];

//# sourceMappingURL=3d860_SecureVoiceShield__next-internal_server_app_api_assess_route_actions_a9a056c7.js.map