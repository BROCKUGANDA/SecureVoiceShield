module.exports=[50823,(e,o,d)=>{}];

//# sourceMappingURL=91859__next-internal_server_app__well-known_api-catalog_route_actions_1d1cfde1.js.map