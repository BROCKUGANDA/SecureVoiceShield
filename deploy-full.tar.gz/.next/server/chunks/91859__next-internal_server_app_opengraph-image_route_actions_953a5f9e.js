module.exports=[78347,(e,o,d)=>{}];

//# sourceMappingURL=91859__next-internal_server_app_opengraph-image_route_actions_953a5f9e.js.map