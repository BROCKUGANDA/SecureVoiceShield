module.exports=[20631,(e,o,d)=>{}];

//# sourceMappingURL=Desktop_SecureVoiceShield__next-internal_server_app_icon_route_actions_376abbd9.js.map