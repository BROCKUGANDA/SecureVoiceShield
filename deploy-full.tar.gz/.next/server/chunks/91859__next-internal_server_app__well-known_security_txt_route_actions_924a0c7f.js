module.exports=[96059,(e,o,d)=>{}];

//# sourceMappingURL=91859__next-internal_server_app__well-known_security_txt_route_actions_924a0c7f.js.map