module.exports=[71944,(e,o,d)=>{}];

//# sourceMappingURL=51034_server_app__well-known_apple-app-site-association_route_actions_b86faf0e.js.map