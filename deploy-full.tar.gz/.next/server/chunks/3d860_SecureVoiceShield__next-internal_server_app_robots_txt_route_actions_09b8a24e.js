module.exports=[6935,(e,o,d)=>{}];

//# sourceMappingURL=3d860_SecureVoiceShield__next-internal_server_app_robots_txt_route_actions_09b8a24e.js.map