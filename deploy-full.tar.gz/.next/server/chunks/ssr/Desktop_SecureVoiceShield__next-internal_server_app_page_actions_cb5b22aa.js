module.exports=[20221,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_SecureVoiceShield__next-internal_server_app_page_actions_cb5b22aa.js.map