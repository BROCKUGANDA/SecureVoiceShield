module.exports=[50682,(e,o,d)=>{}];

//# sourceMappingURL=91859__next-internal_server_app__well-known_assetlinks_json_route_actions_25cab4d4.js.map