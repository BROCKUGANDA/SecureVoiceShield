module.exports=[59991,(e,o,d)=>{}];

//# sourceMappingURL=Desktop_SecureVoiceShield__next-internal_server_app_api_route_actions_81471fda.js.map