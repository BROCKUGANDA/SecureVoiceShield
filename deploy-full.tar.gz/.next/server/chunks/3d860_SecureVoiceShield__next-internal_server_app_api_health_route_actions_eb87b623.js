module.exports=[681,(e,o,d)=>{}];

//# sourceMappingURL=3d860_SecureVoiceShield__next-internal_server_app_api_health_route_actions_eb87b623.js.map