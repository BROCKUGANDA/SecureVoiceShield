module.exports=[8393,(e,o,d)=>{}];

//# sourceMappingURL=3d860_SecureVoiceShield__next-internal_server_app_v1_events_route_actions_e82ee35d.js.map