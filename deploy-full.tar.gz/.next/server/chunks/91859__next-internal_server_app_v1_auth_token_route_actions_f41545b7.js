module.exports=[48250,(e,o,d)=>{}];

//# sourceMappingURL=91859__next-internal_server_app_v1_auth_token_route_actions_f41545b7.js.map