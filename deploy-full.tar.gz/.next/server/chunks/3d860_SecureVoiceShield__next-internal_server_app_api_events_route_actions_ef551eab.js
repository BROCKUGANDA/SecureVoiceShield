module.exports=[22940,(e,o,d)=>{}];

//# sourceMappingURL=3d860_SecureVoiceShield__next-internal_server_app_api_events_route_actions_ef551eab.js.map