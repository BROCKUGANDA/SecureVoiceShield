module.exports=[55210,(e,o,d)=>{}];

//# sourceMappingURL=51034_server_app__well-known_shield-official_json_route_actions_5ccba592.js.map