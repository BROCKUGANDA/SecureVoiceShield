globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/8e5edc6daf9496d6.js",
    "static/chunks/e77678b3929da95a.js",
    "static/chunks/3612e8b56d8787be.js",
    "static/chunks/c18b2197dc3257e9.js",
    "static/chunks/turbopack-ba67acd319147f04.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];