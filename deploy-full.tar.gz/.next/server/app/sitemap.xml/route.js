var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__7e46b260._.js")
R.c("server/chunks/9ce8a_next_5f4174f6._.js")
R.c("server/chunks/9ce8a_next_dist_esm_build_templates_app-route_8a971398.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/3d860_SecureVoiceShield__next-internal_server_app_sitemap_xml_route_actions_dba7d2a2.js")
R.m(96016)
module.exports=R.m(96016).exports
