var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__b458ee2a._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/9ce8a_next_5f4174f6._.js")
R.c("server/chunks/3d860_SecureVoiceShield__next-internal_server_app_robots_txt_route_actions_09b8a24e.js")
R.m(45382)
module.exports=R.m(45382).exports
