var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon/route.js")
R.c("server/chunks/[root-of-the-server]__369eee9a._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/9ce8a_next_5f4174f6._.js")
R.c("server/chunks/Desktop_SecureVoiceShield__next-internal_server_app_icon_route_actions_376abbd9.js")
R.m(15568)
module.exports=R.m(15568).exports
