var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/.well-known/assetlinks.json/route.js")
R.c("server/chunks/[root-of-the-server]__ba65429f._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/91859__next-internal_server_app__well-known_assetlinks_json_route_actions_25cab4d4.js")
R.m(97071)
module.exports=R.m(97071).exports
