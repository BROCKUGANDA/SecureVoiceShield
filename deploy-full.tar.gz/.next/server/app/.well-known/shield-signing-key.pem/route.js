var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/.well-known/shield-signing-key.pem/route.js")
R.c("server/chunks/[root-of-the-server]__6b65e5a0._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/51034_server_app__well-known_shield-signing-key_pem_route_actions_81c592e8.js")
R.m(64029)
module.exports=R.m(64029).exports
