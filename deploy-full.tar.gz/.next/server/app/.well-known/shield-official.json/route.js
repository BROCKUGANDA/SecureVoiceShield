var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/.well-known/shield-official.json/route.js")
R.c("server/chunks/[root-of-the-server]__f7f0d79c._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/51034_server_app__well-known_shield-official_json_route_actions_5ccba592.js")
R.m(4412)
module.exports=R.m(4412).exports
