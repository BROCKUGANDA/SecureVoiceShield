var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/.well-known/api-catalog/route.js")
R.c("server/chunks/[root-of-the-server]__e918cbac._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/91859__next-internal_server_app__well-known_api-catalog_route_actions_1d1cfde1.js")
R.m(23315)
module.exports=R.m(23315).exports
