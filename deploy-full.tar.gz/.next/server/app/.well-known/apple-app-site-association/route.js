var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/.well-known/apple-app-site-association/route.js")
R.c("server/chunks/[root-of-the-server]__0245cd2b._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/51034_server_app__well-known_apple-app-site-association_route_actions_b86faf0e.js")
R.m(79996)
module.exports=R.m(79996).exports
