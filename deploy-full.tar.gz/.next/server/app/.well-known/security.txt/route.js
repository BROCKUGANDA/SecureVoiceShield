var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/.well-known/security.txt/route.js")
R.c("server/chunks/[root-of-the-server]__7543f472._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/91859__next-internal_server_app__well-known_security_txt_route_actions_924a0c7f.js")
R.m(40177)
module.exports=R.m(40177).exports
