1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
0:{"buildId":"WRfOIeO6oKqkX6zi6HydJ","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
