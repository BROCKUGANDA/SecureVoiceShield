1:"$Sreact.fragment"
2:I[51198,["/_next/static/chunks/9dfe03e557a978cd.js","/_next/static/chunks/8bbdae2b90f4843e.js"],"default"]
3:I[23332,["/_next/static/chunks/9dfe03e557a978cd.js","/_next/static/chunks/8bbdae2b90f4843e.js"],"default"]
0:{"buildId":"NQrUlxUQftK814XNpGV0g","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
