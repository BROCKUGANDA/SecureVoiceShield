:HL["/_next/static/chunks/7af0e173cf372ed8.css","style"]
:HL["/_next/static/chunks/6c85c060dece51c1.css","style"]
0:{"buildId":"SbOQWYMY7CvIz-AN8BDeR","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
