var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/voice-check/route.js")
R.c("server/chunks/Desktop_SecureVoiceShield_ccbdc617._.js")
R.c("server/chunks/[root-of-the-server]__0681fbb2._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/Desktop_SecureVoiceShield_src_lib_schemas_ts_c86cabbf._.js")
R.c("server/chunks/91859__next-internal_server_app_api_voice-check_route_actions_c3ae7304.js")
R.m(49043)
module.exports=R.m(49043).exports
