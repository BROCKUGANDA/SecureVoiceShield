var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/verified-calls/route.js")
R.c("server/chunks/Desktop_SecureVoiceShield_0f89ea04._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/[root-of-the-server]__0681fbb2._.js")
R.c("server/chunks/91859__next-internal_server_app_api_verified-calls_route_actions_2fc5ef88.js")
R.m(74141)
module.exports=R.m(74141).exports
