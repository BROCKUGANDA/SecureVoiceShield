var R=require("../../chunks/[turbopack]_runtime.js")("server/app/api/route.js")
R.c("server/chunks/[root-of-the-server]__f82f0a58._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/Desktop_SecureVoiceShield__next-internal_server_app_api_route_actions_81471fda.js")
R.m(59903)
module.exports=R.m(59903).exports
