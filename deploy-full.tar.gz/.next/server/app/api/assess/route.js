var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/assess/route.js")
R.c("server/chunks/Desktop_SecureVoiceShield_src_lib_fba8c9da._.js")
R.c("server/chunks/9ce8a_next_dist_esm_build_templates_app-route_376c6801.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/Desktop_SecureVoiceShield_src_lib_schemas_ts_c86cabbf._.js")
R.c("server/chunks/[root-of-the-server]__0681fbb2._.js")
R.c("server/chunks/3d860_SecureVoiceShield__next-internal_server_app_api_assess_route_actions_a9a056c7.js")
R.m(58382)
module.exports=R.m(58382).exports
