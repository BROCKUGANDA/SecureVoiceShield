var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/reports/route.js")
R.c("server/chunks/Desktop_SecureVoiceShield_a8878896._.js")
R.c("server/chunks/[root-of-the-server]__0681fbb2._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/Desktop_SecureVoiceShield_src_lib_schemas_ts_c86cabbf._.js")
R.c("server/chunks/3d860_SecureVoiceShield__next-internal_server_app_api_reports_route_actions_b12dc6cd.js")
R.m(47589)
module.exports=R.m(47589).exports
