var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[root-of-the-server]__909c1163._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/3d860_SecureVoiceShield__next-internal_server_app_api_health_route_actions_eb87b623.js")
R.m(65356)
module.exports=R.m(65356).exports
