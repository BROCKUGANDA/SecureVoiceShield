var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/audit/route.js")
R.c("server/chunks/[root-of-the-server]__13718f9a._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/3d860_SecureVoiceShield__next-internal_server_app_api_audit_route_actions_39f98b29.js")
R.m(88309)
module.exports=R.m(88309).exports
