var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/audit/segment/route.js")
R.c("server/chunks/[root-of-the-server]__1ecb11a9._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/91859__next-internal_server_app_api_audit_segment_route_actions_2afeffa1.js")
R.m(16585)
module.exports=R.m(16585).exports
