var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/audit/anchor/route.js")
R.c("server/chunks/[root-of-the-server]__75cf2a10._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/91859__next-internal_server_app_api_audit_anchor_route_actions_f429aae8.js")
R.m(68009)
module.exports=R.m(68009).exports
