var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/events/route.js")
R.c("server/chunks/[root-of-the-server]__fc364398._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/3d860_SecureVoiceShield__next-internal_server_app_api_events_route_actions_ef551eab.js")
R.m(54113)
module.exports=R.m(54113).exports
