var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/system/mode/route.js")
R.c("server/chunks/[root-of-the-server]__d79bf987._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/91859__next-internal_server_app_api_system_mode_route_actions_62a75ba6.js")
R.m(33456)
module.exports=R.m(33456).exports
