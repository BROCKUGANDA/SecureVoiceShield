var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/models/route.js")
R.c("server/chunks/[root-of-the-server]__c497be15._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/Desktop_SecureVoiceShield_166cdde2._.js")
R.c("server/chunks/3d860_SecureVoiceShield__next-internal_server_app_api_models_route_actions_14f94e15.js")
R.m(71157)
module.exports=R.m(71157).exports
