var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/appeals/route.js")
R.c("server/chunks/Desktop_SecureVoiceShield_cead3e3e._.js")
R.c("server/chunks/[root-of-the-server]__0681fbb2._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/Desktop_SecureVoiceShield_src_lib_schemas_ts_c86cabbf._.js")
R.c("server/chunks/3d860_SecureVoiceShield__next-internal_server_app_api_appeals_route_actions_2814a218.js")
R.m(57678)
module.exports=R.m(57678).exports
