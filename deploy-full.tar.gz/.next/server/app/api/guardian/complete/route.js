var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/guardian/complete/route.js")
R.c("server/chunks/9ce8a_next_dist_esm_build_templates_app-route_3c30567c.js")
R.c("server/chunks/[root-of-the-server]__0681fbb2._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/Desktop_SecureVoiceShield_src_lib_schemas_ts_c86cabbf._.js")
R.c("server/chunks/91859__next-internal_server_app_api_guardian_complete_route_actions_947989e6.js")
R.m(87292)
module.exports=R.m(87292).exports
