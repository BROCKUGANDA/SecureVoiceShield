var R=require("../../chunks/[turbopack]_runtime.js")("server/app/opengraph-image/route.js")
R.c("server/chunks/[root-of-the-server]__c25ba4f4._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/9ce8a_next_5f4174f6._.js")
R.c("server/chunks/91859__next-internal_server_app_opengraph-image_route_actions_953a5f9e.js")
R.m(92247)
module.exports=R.m(92247).exports
