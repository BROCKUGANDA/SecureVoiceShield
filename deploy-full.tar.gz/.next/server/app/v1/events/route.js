var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/v1/events/route.js")
R.c("server/chunks/[root-of-the-server]__6186c0dc._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/3d860_SecureVoiceShield__next-internal_server_app_v1_events_route_actions_e82ee35d.js")
R.m(40787)
module.exports=R.m(40787).exports
