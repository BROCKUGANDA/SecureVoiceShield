var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/v1/verified-calls/route.js")
R.c("server/chunks/[root-of-the-server]__6e7576fb._.js")
R.c("server/chunks/Desktop_SecureVoiceShield_9e3e1a80._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/Desktop_SecureVoiceShield_src_lib_schemas_ts_c86cabbf._.js")
R.c("server/chunks/91859__next-internal_server_app_v1_verified-calls_route_actions_5abd8339.js")
R.m(94399)
module.exports=R.m(94399).exports
