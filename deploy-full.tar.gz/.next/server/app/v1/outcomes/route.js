var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/v1/outcomes/route.js")
R.c("server/chunks/[root-of-the-server]__87ffaa17._.js")
R.c("server/chunks/Desktop_SecureVoiceShield_src_lib_schemas_ts_c86cabbf._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/3d860_SecureVoiceShield__next-internal_server_app_v1_outcomes_route_actions_65a0cd7b.js")
R.m(2600)
module.exports=R.m(2600).exports
