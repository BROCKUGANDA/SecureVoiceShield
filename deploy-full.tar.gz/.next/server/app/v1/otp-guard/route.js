var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/v1/otp-guard/route.js")
R.c("server/chunks/[root-of-the-server]__0681fbb2._.js")
R.c("server/chunks/Desktop_SecureVoiceShield_3716b79e._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/Desktop_SecureVoiceShield_src_lib_schemas_ts_c86cabbf._.js")
R.c("server/chunks/3d860_SecureVoiceShield__next-internal_server_app_v1_otp-guard_route_actions_283d7daa.js")
R.m(33705)
module.exports=R.m(33705).exports
