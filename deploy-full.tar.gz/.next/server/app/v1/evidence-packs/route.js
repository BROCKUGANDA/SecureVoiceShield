var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/v1/evidence-packs/route.js")
R.c("server/chunks/[root-of-the-server]__6e7576fb._.js")
R.c("server/chunks/Desktop_SecureVoiceShield_becbb466._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/Desktop_SecureVoiceShield_src_lib_schemas_ts_c86cabbf._.js")
R.c("server/chunks/91859__next-internal_server_app_v1_evidence-packs_route_actions_cc0f0a26.js")
R.m(34423)
module.exports=R.m(34423).exports
