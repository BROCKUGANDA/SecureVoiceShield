var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/v1/auth/token/route.js")
R.c("server/chunks/[root-of-the-server]__c0ce058c._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/91859__next-internal_server_app_v1_auth_token_route_actions_f41545b7.js")
R.m(34256)
module.exports=R.m(34256).exports
