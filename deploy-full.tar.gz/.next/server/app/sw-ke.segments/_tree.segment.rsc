:HL["/_next/static/css/15730e9f7c5c55ef.css","style"]
:HL["/_next/static/css/9a2cc6222a9b4e7b.css","style"]
0:{"buildId":"BsDMYMwj0DRTCsWGp4BD8","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"locale","paramType":"d","paramKey":"sw-ke","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
