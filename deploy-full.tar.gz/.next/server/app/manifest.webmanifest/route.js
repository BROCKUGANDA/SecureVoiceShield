var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.webmanifest/route.js")
R.c("server/chunks/[root-of-the-server]__8f184771._.js")
R.c("server/chunks/[root-of-the-server]__a4b230d3._.js")
R.c("server/chunks/91859__next-internal_server_app_manifest_webmanifest_route_actions_32467c93.js")
R.m(27459)
module.exports=R.m(27459).exports
